
Instructions to setup Management OData web service endpoint:

1. Copy the Microsoft.Samples.Management.OData.BasicPlugins.dll to current folder. Or build the sample.

2. Execute .\setupEndPoint.ps1
