//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CaptureEngine.rc
//
#define IDR_MENU1                       101
#define IDD_CHOOSE_DEVICE               102
#define IDS_ERR_SET_DEVICE              103
#define IDS_ERR_INITIALIZE              104
#define IDS_ERR_PREVIEW                 105
#define IDS_ERR_RECORD                  106
#define IDS_ERR_CAPTURE                 107
#define IDS_ERR_PHOTO                   108
#define IDC_DEVICE_LIST                 1001
#define IDC_STATUS_BAR                  1002
#define ID_CAPTURE_CHOOSEDEVICE         40001
#define ID_CAPTURE_STARTRECORDING       40002
#define ID_CAPTURE_RECORD               40003
#define ID_CAPTURE_TAKEPHOTO            40004
#define ID_CAPTURE_PREVIEW              40005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40005
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
